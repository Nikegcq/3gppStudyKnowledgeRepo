// (c) 2024 Tietoevry, Inc. All rights reserved. Unauthorized use,

// reproduction, or distribution of this software is strictly prohibited.

#ifndef SWM_API_H
#define SWM_API_H

#define SWM_SLOT_VALID          2
#define SWM_SLOT_INVALID        1
#define SWM_SLOT_EMPTY          0

#define IMAGE_FULL_PATH "/tmp/image.zip"

struct file_info_t {
        char file_name[32];
        char file_rev[16];
        char local_path[64];
        int integrity;
};

struct slot_product_entry_t {
	int slot;	/*slot number of this slot*/
	char slot_name[32]; /*slot name*/
	int is_writable; /* readonly or readwrite*/
	int status;     /*this slot is valid or not or empty*/
	int is_active;	/*this slot is active or not*/
	int is_current;	/*this slot is the current working one*/
	int num_of_images; /*number of images in slot*/
	char build_name[32];	/*bldName*/
	char build_rev[16];	/*bldVersion*/
        struct file_info_t fileInfo[3];
};

int api_resetFwd(void);
int api_installSoftware(int slotNo, char *fileName);
int api_activateSlot(int slotNo);
int api_getSlotInfo(int *num_of_slot, struct slot_product_entry_t **product_entry);

#endif
