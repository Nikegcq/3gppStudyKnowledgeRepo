// (c) 2024 Tietoevry, Inc. All rights reserved. Unauthorized use,

// reproduction, or distribution of this software is strictly prohibited.

#ifndef SWMD_HANDLER_H
#define SWMD_HANDLER_H

#include "swmd_api.h"

int install_software_handler(int slotNo, char *fileName);

int activate_slot_handler(int slotNo);

int reset_board_handler(void);

int inventory_handler(int *num_of_slot, struct slot_product_entry_t **product_entry);

/**
 * @brief Copy SRC to DEST and check length.
 */
void saft_strcpy(char * dest, char *src, size_t dest_size);
#endif
