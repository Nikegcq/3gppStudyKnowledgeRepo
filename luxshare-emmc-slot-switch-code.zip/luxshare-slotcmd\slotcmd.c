// (c) 2024 Tietoevry, Inc. All rights reserved. Unauthorized use,

// reproduction, or distribution of this software is strictly prohibited.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include "swm_api.h"

static int print_usage(void)
{
    printf("Usage: slotcmd [a|h|i|l|r|s]\n");
    printf("-h : Print usage\n");
    printf("-a <slotNo>: Activate SW in slot number <slotNo>, should be 0 or 1\n");
    printf("-i <slotNo>: Install SW to <slotNo>, should be 0 or 1\n");
    printf("-l : List information in all slots\n");
    printf("-r : Restart to slot number set by -a option\n");
    return 0;
}

static int cmd_activate(int slotNo)
{
    int rc;

    if (slotNo != 0 && slotNo != 1) {
        printf("ERR: slot number should be 0 and 1\n");
        return -1;
    }

    rc = api_activateSlot(slotNo);
    if (rc != 0) {
        printf("ERR: activate slot %d failed\n", slotNo);
        return -1;
    }

    printf("Activate slot %d done\n", slotNo);
    return 0;
}

static int cmd_install(int slotNo)
{
    int rc;

    rc = api_installSoftware(slotNo, IMAGE_FULL_PATH);
    if (rc != 0) {
        printf("ERR: install software to slot %d failed\n", slotNo);
        return -1;
    }

    printf("Install software to slot %d done\n", slotNo);
    return 0;
}

static int cmd_list(void)
{
    int rc;
    int num_of_slot = 0;
    struct slot_product_entry_t *product_entry;
    struct slot_product_entry_t *pe;

    rc = api_getSlotInfo(&num_of_slot, &product_entry);
    if (rc != 0) {
        printf("ERR: get slot info failed\n");
        return -1;
    }

    pe = product_entry;
    printf("%-6s  %-8s  %-8s  %-8s %-16s %-8s %-8s %-8s %-10s %-8s %-10s %-8s %-10s\n",
	    "slotNo",
	    "Access",
	    "Act",
	    "Cur",
	    "bldName",
	    "bldVer",
	    "imageNo",
	    "file1",
	    "file1_rev",
	    "file2",
	    "file2_rev",
	    "file3",
	    "file3_rev");
    for (int i = 0; i < num_of_slot; i++, pe++)
    {
        if (pe->status) {
            printf("%-6d  %-8s  %-8s  %-8s %-16s %-8s %-8d %-8s %-10s %-8s %-10s %-8s %-10s\n",
	            pe->slot,
		    pe->is_writable ? "W/R" : "R",
		    pe->is_active ? "Active" : "Deactive",
		    pe->is_current ? "Working" : "Valid",
		    pe->build_name,
		    pe->build_rev,
		    pe->num_of_images,
		    pe->fileInfo[0].file_name,
		    pe->fileInfo[0].file_rev,
		    pe->fileInfo[1].file_name,
		    pe->fileInfo[1].file_rev,
		    pe->fileInfo[2].file_name,
		    pe->fileInfo[2].file_rev);
        }
    }

    free(product_entry);
    return 0;
}

static int cmd_reset(void)
{
    int rc = 0;
    
    rc = api_resetFwd();
    if (rc != 0) {
        printf("ERR: reset slot failed\n");
        return -1;
    }

    return 0;
}

static int get_slot_num(char *option_arg)
{
    int slotNo;
    char *endptr = NULL;

    slotNo = strtol(option_arg, &endptr, 0);

    if (*endptr != '\0') {
        printf("ERR: slot number incorrect\n");
        return -1;
    }

    return slotNo;
}

int main(int argc, char **argv)
{
    const char sopts[] = "a:hi:lrs:";
    const struct option lopts[] = {
	    { "activate",	required_argument,	NULL, 'a' },
	    { "help",		no_argument,		NULL, 'h' },
	    { "install",	required_argument,	NULL, 'i' },
	    { "list",		no_argument,		NULL, 'l' },
	    { "reset",		no_argument,		NULL, 'r' },
	    { "show",		required_argument,	NULL, 's' },
	    { 0, 0, 0, 0 }
    };

    int c;
    int optind = 0;
    int slotNo;

    if (argc < 2) {
        print_usage();
        return -1;
    }

    while ((c = getopt_long(argc, argv, sopts, lopts, &optind)) != -1) {
        switch(c) {
            case 'a':
                slotNo = get_slot_num(optarg);
	        cmd_activate(slotNo);
                break;
            case 'h':
                print_usage();
                return 0;
            case 'i':
                slotNo = get_slot_num(optarg);
                cmd_install(slotNo);
                break;
            case 'l':
                cmd_list();
                break;
            case 'r':
                cmd_reset();
                break;
            case 's':
                slotNo = get_slot_num(optarg);
                printf("slotNo is %d\n", slotNo);
                break;
            default:
                printf("ERR: wrong option\n");
                print_usage();
                break;
        }
    }

    return 0;
}
