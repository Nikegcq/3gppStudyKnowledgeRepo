// (c) 2024 Tietoevry, Inc. All rights reserved. Unauthorized use,

// reproduction, or distribution of this software is strictly prohibited.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/reboot.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <syslog.h>
#include "swm_api.h"
#include "swmd_api.h"

static int get_msgqid(void)
{
	key_t key;
	int msgqid;

	key = ftok(SWMD_MSGQ_FILE_FULLPATH, 1);
	if (key == -1) {
		syslog(ERROR, "ftok failed\n");
		return -1;
	}

	msgqid = msgget(key, 0);

	return msgqid;
}

int api_installSoftware(int slotNo, char *fileName)
{
	struct swmd_msg_install_req_t msg_req;
	struct swmd_msg_install_cfm_t msg_cfm;
	int msgqid;
	int rx_len;
	int rc;

	syslog(INFO, "It is going to install new software %s to slot %d.\n", fileName, slotNo);

	msgqid = get_msgqid();
	if (msgqid == -1) {
		syslog(ERROR, "msgget failed, errno %d\n", errno);
		return -1;
	}

	msg_req.mtype = SWMD_MSG_INSTALL_REQ;
	msg_req.slotNo = slotNo;
	strcpy(msg_req.fileName, fileName);
	rc = msgsnd(msgqid, &msg_req, sizeof(struct swmd_msg_install_req_t) - sizeof(long), 0);
	if (rc != 0) {
		syslog(ERROR, "Send install request message failed, errno %d\n", errno);
		return -1;
	}

	rx_len = msgrcv(msgqid, &msg_cfm, sizeof(struct swmd_msg_install_cfm_t) - sizeof(long), SWMD_MSG_INSTALL_CFM, 0);
	if (rx_len < 0) {
		syslog(ERROR, "Receive message failed, errno %d\n", errno);
		return -1;
	}
	if (msg_cfm.mtype != SWMD_MSG_INSTALL_CFM) {
		syslog(ERROR, "Received wrong message\n");
		return -1;
	}

	if (msg_cfm.result != SWMD_MSG_SUCCESS) {
		syslog(ERROR, "Install software failed\n");
		return -1;
	}

	syslog(INFO, "Received install confirm with success result\n");
	return 0;
}

int api_activateSlot(int slotNo)
{
	struct swmd_msg_activate_req_t msg_req;
	struct swmd_msg_activate_cfm_t msg_cfm;
	int msgqid;
	int rx_len;
	int rc;

	syslog(INFO, "Activate software in slot %d\n", slotNo);

	msgqid = get_msgqid();
	if (msgqid == -1) {
		syslog(ERROR, "msgget failed, errno %d\n", errno);
		return -1;
	}

	msg_req.mtype = SWMD_MSG_ACTIVATE_REQ;
	msg_req.slotNo = slotNo;
	rc = msgsnd(msgqid, &msg_req, sizeof(struct swmd_msg_activate_req_t) - sizeof(long), 0);
	if (rc != 0) {
		syslog(ERROR, "Send message failed, errno %d\n", errno);
		return -1;
	}

	rx_len = msgrcv(msgqid, &msg_cfm, sizeof(struct swmd_msg_activate_cfm_t) - sizeof(long), SWMD_MSG_ACTIVATE_CFM, 0);
	if (rx_len < 0) {
		syslog(ERROR, "Receive message failed, errno %d\n", errno);
		return -1;
	}
	if (msg_cfm.mtype != SWMD_MSG_ACTIVATE_CFM) {
		syslog(ERROR, "Received wrong message\n");
		return -1;
	}

	if (msg_cfm.result != SWMD_MSG_SUCCESS) {
		syslog(ERROR, "Actiave slot failed\n");
		return -1;
	}

	syslog(INFO, "Received activate confirm with success result\n");
	return 0;

}

int api_resetFwd(void)
{
	struct swmd_msg_reset_req_t msg_req;
	struct swmd_msg_reset_cfm_t msg_cfm;
	int msgqid;
	int rx_len;
	int rc;

	syslog(INFO, "It is going to reset board\n");

	msgqid = get_msgqid();
	if (msgqid == -1) {
		syslog(ERROR, "msgget failed, errno %d\n", errno);
		return -1;
	}

	msg_req.mtype = SWMD_MSG_RESET_REQ;
	rc = msgsnd(msgqid, &msg_req, sizeof(struct swmd_msg_reset_req_t) - sizeof(long), 0);
	if (rc != 0) {
		syslog(ERROR, "Send message failed, errno %d\n", errno);
		return -1;
	}

	rx_len = msgrcv(msgqid, &msg_cfm, sizeof(struct swmd_msg_reset_cfm_t) - sizeof(long), SWMD_MSG_RESET_CFM, 0);
	if (rx_len < 0) {
		syslog(ERROR, "Receive message failed, errno %d\n", errno);
		return -1;
	}
	if (msg_cfm.mtype != SWMD_MSG_RESET_CFM) {
		syslog(ERROR, "Received wrong message\n");
		return -1;
	}

	if (msg_cfm.result != SWMD_MSG_SUCCESS) {
		syslog(ERROR, "Reset board failed\n");
		return -1;
	}

	syslog(ERROR, "Received reset board confirm with success result\n");
	return 0;
}

int api_getSlotInfo(int *num_of_slot, struct slot_product_entry_t **product_entry)
{
	struct swmd_msg_inventory_req_t msg_req;
	struct swmd_msg_inventory_cfm_t *msg_cfm;
	int msgqid;
	//struct msginfo info;
	//int max_msgsize;
	int rx_len;
	int rc;

	syslog(INFO, "It is going to get slot info\n");
	msgqid = get_msgqid();
	if (msgqid == -1) {
		syslog(ERROR, "msgget failed, errno %d\n", errno);
		return -1;
	}

	msg_req.mtype = SWMD_MSG_INVENTORY_REQ;
	rc = msgsnd(msgqid, &msg_req, sizeof(struct swmd_msg_inventory_req_t) - sizeof(long), 0);
	if (rc != 0) {
		syslog(ERROR, "Send message failed, errno %d\n", errno);
		return -1;
	}

#if 0 //bug LUXSHARE-108
        rc = msgctl(msgqid, MSG_INFO, (struct msqid_ds *)&info);
        if (rc != 0) {
                syslog(ERROR, "Failed to get IPC INFO, errno %d\n", errno);
                return -1;
        }

        max_msgsize = info.msgmax;

	msg_cfm = (struct swmd_msg_inventory_cfm_t *)malloc(max_msgsize);
#else
	msg_cfm = (struct swmd_msg_inventory_cfm_t *)malloc(4096);
#endif
	if (msg_cfm == NULL) {
		syslog(ERROR, "malloc failed\n");
		return -1;
	}
#if 0 //bug LUXSHARE-108
	rx_len = msgrcv(msgqid, msg_cfm, max_msgsize - sizeof(long), SWMD_MSG_INVENTORY_CFM, 0);
#else
	rx_len = msgrcv(msgqid, msg_cfm, 4096 - sizeof(long), SWMD_MSG_INVENTORY_CFM, 0);
#endif
	if (rx_len < 0) {
		syslog(ERROR, "Receive message failed, errno %d\n", errno);
		if (msg_cfm)
			free(msg_cfm);
		return -1;
	}
	if (msg_cfm->mtype != SWMD_MSG_INVENTORY_CFM) {
		syslog(ERROR, "Received wrong message\n");
		if (msg_cfm)
			free(msg_cfm);
		return -1;
	}

	if (msg_cfm->result != SWMD_MSG_SUCCESS) {
		syslog(ERROR, "Get slot info failed\n");
		if (msg_cfm)
			free(msg_cfm);
		return -1;
	}

	syslog(INFO, "Received get slot info confirm with success result\n");

	*num_of_slot = msg_cfm->num_of_slot;
	*product_entry = (struct slot_product_entry_t *)malloc(sizeof(struct slot_product_entry_t) * (*num_of_slot));
	if (*product_entry == NULL) {
		syslog(ERROR, "malloc failed\n");
		if (msg_cfm)
			free(msg_cfm);
		return -1;
	}
	memcpy(*product_entry, msg_cfm->product_entry, sizeof(struct slot_product_entry_t) * (*num_of_slot));

	if (msg_cfm)
		free(msg_cfm);

	return 0;
}
