FILESEXTRAPATHS:prepend := "${THISDIR}/files:"

SRC_URI:append = " file://platform-top.h file://bsp.cfg"
SRC_URI += "file://user_2024-04-09-09-41-00.cfg \
            file://user_2024-07-22-06-21-00.cfg \
            file://user_2024-07-22-06-49-00.cfg \
            file://user_2024-07-23-02-10-00.cfg \
            file://0001-zynqmp-Add-multiboot-select-for-Lux.patch \
            file://0001-Add-bootmode-fallback-handling.patch \
            file://0001-Add-crash-bits-in-resetmem-reg.patch \
            file://user_2024-11-07-03-33-00.cfg \
            "

SRCREV = "40a08d69e749c0472103551c85c02c41f979453d"

