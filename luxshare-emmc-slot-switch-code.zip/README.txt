﻿# Luxshare eMMC Slot 切换相关代码打包

来源（WSL）：/home/congqiang/work/repo/...

## 目录说明

1. luxshare-slotcmd/     — CLI：slotcmd -i/-a/-l/-r
2. luxshare-swmapi/      — 公共 API 头 swm_api.h
3. luxshare-libswm/      — msgq 客户端库
4. luxshare-swmd/        — 守护进程：eMMC 分区读写 + config_reg 切 slot
5. u-boot-patches/       — ZynqMP U-Boot 补丁（multi_boot / distro_bootpart / fallback）

## 关键链路

slotcmd -> libswm -> swmd
swmd reset: write CSU multi_boot 0xFFCA0010 = slot (0/1), ORDERED reboot
U-Boot: distro_bootpart = multi_boot+2  (slot0->p2, slot1->p3)
p1: BOOT.BIN / BOOT0001.BIN
p2/p3: boot.scr, image.ub, manifest, active/valid flags

注意：U-Boot/FSBL 自身损坏时，仅靠 U-Boot 内 handle_fallback 无法回滚。
