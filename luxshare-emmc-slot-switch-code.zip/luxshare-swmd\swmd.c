// (c) 2024 Tietoevry, Inc. All rights reserved. Unauthorized use,

// reproduction, or distribution of this software is strictly prohibited.

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <syslog.h>
#include "swmd_handler.h"
#include "swmd_api.h"

char msgq_file[128];
uint8_t bootmode;

union swmd_msg_t {
        long mtype;
        struct swmd_msg_install_req_t install_req;
        struct swmd_msg_install_cfm_t install_cfm;
        struct swmd_msg_activate_req_t activate_req;
        struct swmd_msg_activate_cfm_t activate_cfm;
        struct swmd_msg_reset_req_t reset_req;
        struct swmd_msg_reset_cfm_t reset_cfm;
        struct swmd_msg_inventory_req_t invent_req;
        struct swmd_msg_inventory_cfm_t invent_cfm;
};

static int create_env(void)
{

	FILE *fp = NULL;
	int rc = -1;

	syslog(INFO, "create msgq env file\n");

	strcpy(msgq_file, SWMD_RUNDIR_PATH);
	strcat(msgq_file, SWMD_MSGQ_FILE);

	rc = mkdir(SWMD_RUNDIR_PATH, 0777);
	if (rc < 0) {
		syslog(ERROR, "Fail to create path %s\n", SWMD_RUNDIR_PATH);
		return -1;
	}

	fp = fopen(msgq_file, "w");
	if (fp == NULL) {
		syslog(ERROR, "Fail to open %s\n", SWMD_MSGQ_FILE);
		return -1;
	}

	rc = fclose(fp);
	if (rc != 0) {
		syslog(ERROR, "Fail to close %s\n", SWMD_MSGQ_FILE);
		return -1;
	}

	return 0;
}

static void handle_install_req(int msgqid, union swmd_msg_t *msgp)
{
	struct swmd_msg_install_req_t *install_req = (struct swmd_msg_install_req_t *)msgp;
	struct swmd_msg_install_cfm_t install_cfm;
	int slotNo;
	char fileName[SWMD_FILENAME_MAXSIZE];
	int rc;

	syslog(INFO, "received message:\n");
	syslog(INFO, "install software to slot %d\n", install_req->slotNo);
	syslog(INFO, "fileName %s\n", install_req->fileName);

	slotNo = install_req->slotNo;
	snprintf(fileName, sizeof(fileName), "%s", install_req->fileName);

	install_cfm.mtype = SWMD_MSG_INSTALL_CFM;
	rc = install_software_handler(slotNo, fileName);
	if (rc != 0) {
		syslog(ERROR, "Install software failed\n");
		/* Send back confirm with failure result */
		install_cfm.result = SWMD_MSG_FAILURE;
		goto send_msg;
	}

	install_cfm.result = SWMD_MSG_SUCCESS;

send_msg:
	msgsnd(msgqid, &install_cfm, sizeof(struct swmd_msg_install_cfm_t) - sizeof(long), 0);
	return;
}
static void handle_activate_req(int msgqid, union swmd_msg_t *msgp)
{
	struct swmd_msg_activate_req_t *activate_req = (struct swmd_msg_activate_req_t *)msgp;
	struct swmd_msg_activate_cfm_t activate_cfm;
	int slotNo;
	int rc;

	slotNo = activate_req->slotNo;
	activate_cfm.mtype = SWMD_MSG_ACTIVATE_CFM;
	rc = activate_slot_handler(slotNo);
	if (rc != 0) {
		syslog(ERROR, "Activate slot %d failed\n", slotNo);
		activate_cfm.result = SWMD_MSG_FAILURE;
		goto send_msg;
	}

	activate_cfm.result = SWMD_MSG_SUCCESS;
send_msg:
	msgsnd(msgqid, &activate_cfm, sizeof(struct swmd_msg_activate_cfm_t) - sizeof(long), 0);
	return;
}

static void handle_reset_req(int msgqid)
{
	int rc;
	struct swmd_msg_reset_cfm_t reset_cfm;

	reset_cfm.mtype = SWMD_MSG_RESET_CFM;

	rc = reset_board_handler();
	if (rc != 0) {
		syslog(ERROR, "Reset board failed\n");
		reset_cfm.result = SWMD_MSG_FAILURE;
		goto send_msg;
	}

	reset_cfm.result = SWMD_MSG_SUCCESS;
send_msg:
	msgsnd(msgqid, &reset_cfm, sizeof(struct swmd_msg_reset_cfm_t) - sizeof(long), 0);
	return;
}

static void handle_inventory_req(int msgqid)
{
	int rc;
	int num_of_slot = 0;
	struct swmd_msg_inventory_cfm_t *invent_cfm = NULL;
	struct slot_product_entry_t *product_entry = NULL;

	rc = inventory_handler(&num_of_slot, &product_entry);
	if (rc != 0) {
		syslog(ERROR, "Failed to get inventory\n");
		invent_cfm = (struct swmd_msg_inventory_cfm_t *)malloc(sizeof(struct swmd_msg_inventory_cfm_t));
		if (invent_cfm == NULL) {
			syslog(ERROR, "malloc failed\n");
			goto fail;
		}
		invent_cfm->mtype = SWMD_MSG_INVENTORY_CFM;
		invent_cfm->result = SWMD_MSG_FAILURE;
		invent_cfm->num_of_slot = 0;
	}
	else {
		invent_cfm = (struct swmd_msg_inventory_cfm_t *)malloc(sizeof(struct swmd_msg_inventory_cfm_t) + sizeof(struct slot_product_entry_t) * num_of_slot);
		if (invent_cfm == NULL) {
			syslog(ERROR, "malloc failed\n");
			goto fail;
		}
		invent_cfm->mtype = SWMD_MSG_INVENTORY_CFM;
		invent_cfm->result = SWMD_MSG_SUCCESS;
		invent_cfm->num_of_slot = num_of_slot;
		memcpy(invent_cfm->product_entry, product_entry, num_of_slot * sizeof(struct slot_product_entry_t));
	}

send_msg:
	msgsnd(msgqid, invent_cfm, sizeof(struct swmd_msg_inventory_cfm_t) + sizeof(struct slot_product_entry_t) * num_of_slot - sizeof(long), 0);

fail:
	if (invent_cfm != NULL)
		free(invent_cfm);
	if (product_entry != NULL)
		free(product_entry);
	return;
}

int get_bootmode()
{
	char run_command[128];
	char output[32];
	FILE *fp;
	char *p;
	char *endptr = NULL;
	uint32_t gen_storage1 = 0;
	int rc;

	snprintf(run_command, sizeof(run_command), "echo FFD80054 > /sys/firmware/zynqmp/config_reg");

	rc = system(run_command);
	if (rc == -1) {
		syslog(ERROR, "Run %s command failed\n", run_command);
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Command %s failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	snprintf(run_command, sizeof(run_command), "cat /sys/firmware/zynqmp/config_reg");

	fp = popen(run_command, "r");
	if (fp == NULL) {
		syslog(ERROR, "popen failed\n");
		return -1;
	}

	p = fgets(output, sizeof(output), fp);
	if (p == NULL) {
		syslog(ERROR, "fgets failed\n");
		fclose(fp);
		return -1;
	}

	rc = fclose(fp);
	if (rc == -1) {
		syslog(ERROR, "fclose failed\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	gen_storage1 = strtol(output, &endptr, 0);
	if (*endptr == ' ') {
		syslog(INFO, "Meet blank character in output\n");
	}
	/* gen_storage1 bit4~7 are for boot mode*/
	bootmode = (gen_storage1 & PERS_GEN_STORAGE1_BOOTMODE_MASK) >> PERS_GEN_STORAGE1_BOOTMODE_SHIFT;
	syslog(INFO, "Bootmode is 0x%x\n", bootmode);
	return 0;
}

int main(int argc, char **argv)
{
	int msgqid;
	size_t rx_len;
	key_t key;
	struct msginfo info;
	char *rx_buf = NULL;
	union swmd_msg_t *msgp;
	int max_msgsize;
	int rc = 0;

	rc = create_env();
	if (rc != 0) {
		syslog(ERROR, "Create env failed\n");
		return -1;
	}

	key = ftok(msgq_file, 1);
	if (key == -1) {
		syslog(ERROR, "Get key failed\n");
		return -1;
	}
	msgqid = msgget(key, IPC_CREAT | 0666);
	if (msgqid == -1) {
		syslog(ERROR, "msgget failed, errno %d\n", errno);
		return -1;
	}

	rc = msgctl(msgqid, MSG_INFO, (struct msqid_ds *)&info);
	if (rc != 0) {
		syslog(ERROR, "msgctl failed to get IPC INFO, errno %d\n", errno);
		return -1;
	}

	max_msgsize = info.msgmax;
	syslog(INFO, "msgqid %d created, max_msgsize %d\n", msgqid, max_msgsize);
	rx_buf = malloc(max_msgsize);
	if (rx_buf == NULL) {
		syslog(ERROR, "malloc failed\n");
		return -1;
	}

	rc = get_bootmode();
	if (rc != 0) {
		syslog(ERROR, "Get bootmode failed\n");
		return -1;
	}

	while (1) {
		rx_len = msgrcv(msgqid, rx_buf, max_msgsize - sizeof(long), 0, 0);
		if (rx_len < 0) {
			syslog(ERROR, "Receive message failed, errno %d\n", errno);
			continue;
		}

		msgp = (union swmd_msg_t *)rx_buf;
		syslog(DEBUG, "Recieved message type: 0x%lx\n", msgp->mtype);
		switch (msgp->mtype) {
		case SWMD_MSG_INSTALL_REQ:
			handle_install_req(msgqid, msgp);
			break;
		case SWMD_MSG_ACTIVATE_REQ:
			handle_activate_req(msgqid, msgp);
			break;
		case SWMD_MSG_RESET_REQ:
			handle_reset_req(msgqid);
			break;
		case SWMD_MSG_INVENTORY_REQ:
			handle_inventory_req(msgqid);
			break;
		default:
			syslog(ERROR, "Message not supported in SWMD\n");
			break;
		}

	}

	free(rx_buf);
	return 0;
}
