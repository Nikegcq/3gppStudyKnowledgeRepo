// (c) 2024 Tietoevry, Inc. All rights reserved. Unauthorized use,

// reproduction, or distribution of this software is strictly prohibited.

#ifndef SWMD_API_H
#define SWMD_API_H

#include <stdint.h>
#include "swm_api.h"

#define SWMD_FILENAME_MAXSIZE	128

#define SWMD_RUNDIR_PATH        "/var/run/swmd/"
#define SWMD_MSGQ_FILE          "swmd_msgq_file"
#define SWMD_MSGQ_FILE_FULLPATH          "/var/run/swmd/swmd_msgq_file"

#define SWMD_MSG_BASE	0xabcd0000
#define SWMD_MSG_INSTALL_REQ	(SWMD_MSG_BASE + 1)
#define SWMD_MSG_INSTALL_CFM	(SWMD_MSG_BASE + 2)
#define SWMD_MSG_ACTIVATE_REQ	(SWMD_MSG_BASE + 3)
#define SWMD_MSG_ACTIVATE_CFM	(SWMD_MSG_BASE + 4)
#define SWMD_MSG_RESET_REQ	(SWMD_MSG_BASE + 5)
#define SWMD_MSG_RESET_CFM	(SWMD_MSG_BASE + 6)
#define SWMD_MSG_INVENTORY_REQ	(SWMD_MSG_BASE + 7)
#define SWMD_MSG_INVENTORY_CFM	(SWMD_MSG_BASE + 8)

#define SWMD_MSG_SUCCESS	0
#define SWMD_MSG_FAILURE	-1

#define QSPI_MODE_24BIT 0x00000001
#define QSPI_MODE_32BIT 0x00000002
#define SD_MODE         0x00000003 /* sd 0 */
#define SD_MODE1        0x00000005 /* sd 1 */
#define NAND_MODE       0x00000004
#define EMMC_MODE       0x00000006
#define USB_MODE        0x00000007
#define SD1_LSHFT_MODE  0x0000000E /* SD1 Level shifter */
#define JTAG_MODE       0x00000000
#define PERS_GEN_STORAGE1_BOOTMODE_MASK		0x000000F0
#define PERS_GEN_STORAGE1_BOOTMODE_SHIFT	4
#define PERS_GEN_STORAGE1_RESTART_TYPE_MASK	0x00000F00
#define PERS_GEN_STORAGE1_RESTART_TYPE_SHIFT	8
#define RESTART_TYPE_CRASH      0
#define RESTART_TYPE_ORDERED    1

extern uint8_t bootmode;

enum log_level
{
    EMERGENCY,  /**< system is unusable.               */
    ALERT,      /**< action must be taken immediately. */
    CRITICAL,   /**< critical conditions.              */
    ERROR,      /**< error conditions.                 */
    WARNING,    /**< warning conditions.               */
    NOTICE,     /**< normal but significant condition. */
    INFO,       /**< informational messages.           */
    DEBUG,      /**< debug-level messages.             */
};

struct image_info_t {
        int num_of_images;
        char build_name[32];
        char build_rev[16];
        struct file_info_t fileInfo[3];
};

struct swmd_msg_install_req_t {
	long mtype;
	int slotNo;	/* which slot to install, should be 0 or 1. */
	char fileName[SWMD_FILENAME_MAXSIZE];	/* full path and file name of zip file to install*/
};

struct swmd_msg_install_cfm_t {
	long mtype;
	int result;	/* success or failure*/
};

struct swmd_msg_activate_req_t {
	long mtype;
	int slotNo;
};

struct swmd_msg_activate_cfm_t {
	long mtype;
	int result;
};

struct swmd_msg_reset_req_t {
	long mtype;
};

struct swmd_msg_reset_cfm_t {
	long mtype;
	int result;
};

struct swmd_msg_inventory_req_t {
	long mtype;
};

struct swmd_msg_inventory_cfm_t {
	long mtype;
	int result;
	int num_of_slot;
	struct slot_product_entry_t product_entry[0];
};

#endif
