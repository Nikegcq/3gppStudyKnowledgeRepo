// (c) 2024 Tietoevry, Inc. All rights reserved. Unauthorized use,

// reproduction, or distribution of this software is strictly prohibited.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/reboot.h>
#include <syslog.h>
#include "swmd_handler.h"
#include "swmd_api.h"

#define MAX_SLOT_NUM	2
#define MAX_SLOT_NUMBER  1
#define BOOT_BIN_PARTITION 1
/*bootmode: SD_MODE1 is EMMC in Luxshare, SD_MODE is SD in Luxshare*/
/*bootmode: SD1_LSHFT_MODE is SD for ZCU102*/
#define BOOT_PARTITION_SD "/run/media/mmcblk0p1/"
#define IMAGE_PARTITION_0_SD "/run/media/mmcblk0p2/"
#define IMAGE_PARTITION_1_SD "/run/media/mmcblk0p3/"
#define BOOT_PARTITION_EMMC "/run/media/mmcblk1p1/"
#define IMAGE_PARTITION_0_EMMC "/run/media/mmcblk1p2/"
#define IMAGE_PARTITION_1_EMMC "/run/media/mmcblk1p3/"

#define TMP_IMAGE_DIR  "/tmp/"
#define SLOT_ACTIVE_FLAG_FILENAME "slot_active_file.txt"
#define SLOT_VALID_FLAG_FILENAME "slot_valid_file.txt"
#define SLOT_MANIFEST_FILENAME "manifest.xml"
#define FILE_NAME_PATTERN "fileName"
#define FILE_VERSION_PATTERN "fileVersion"
#define BUILD_NAME_PATTERN "bldName"
#define BUILD_VERSION_PATTERN "bldVersion"

static int store_bootbin(int slotNo, char *bootName)
{
	char boot_name[128];
	char cp_boot[128];
	int rc;

	if (bootName == NULL) {
		syslog(ERROR, "Boot image name should not be NULL\n");
		return -1;
	}
	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}

	/* Now we only support EMMC in Luxshare and SD in ZCU102*/
	if (bootmode == SD_MODE1) {
		sprintf(boot_name, BOOT_PARTITION_EMMC);
	}
	else {
		sprintf(boot_name, BOOT_PARTITION_SD);
	}

	if (bootmode == SD_MODE1) {
		if (slotNo == 0) {
			snprintf(boot_name, sizeof(boot_name), "%s%s", BOOT_PARTITION_EMMC, "BOOT.BIN");
		}
		else {
			snprintf(boot_name, sizeof(boot_name), "%s%s%d%s", BOOT_PARTITION_EMMC, "BOOT000", slotNo, ".BIN");
		}
	}
	else {
		if (slotNo == 0) {
			snprintf(boot_name, sizeof(boot_name), "%s%s", BOOT_PARTITION_SD, "BOOT.BIN");
		}
		else {
			snprintf(boot_name, sizeof(boot_name), "%s%s%d%s", BOOT_PARTITION_SD, "BOOT000", slotNo, ".BIN");
		}
	}

	sprintf(cp_boot, "cp -f %s %s", bootName, boot_name);
	syslog(INFO, "Copying %s to %s\n", bootName, boot_name);
	rc = system(cp_boot);
	if (rc == -1) {
		syslog(ERROR, "Failed to install boot bin\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", cp_boot, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", cp_boot, rc);
		return -1;
	}
	syslog(INFO, "Done!\n");

	return 0;
}

static int store_image(int slotNo, char *imageName)
{
	char cp_image[128];
	char target_image[128];
	int rc;

	if (imageName == NULL) {
		syslog(ERROR, "Image name is NULL\n");
		return -1;
	}
	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}

	if (bootmode == SD_MODE1) {
		if (slotNo == 0) {
			snprintf(target_image, sizeof(target_image), "%s", IMAGE_PARTITION_0_EMMC);
		}
		else if (slotNo == 1) {
			snprintf(target_image, sizeof(target_image), "%s", IMAGE_PARTITION_1_EMMC);
		}
	}
	else {
		if (slotNo == 0) {
			snprintf(target_image, sizeof(target_image), "%s", IMAGE_PARTITION_0_SD);
		}
		else if (slotNo == 1) {
			snprintf(target_image, sizeof(target_image), "%s", IMAGE_PARTITION_1_SD);
		}
	}

	snprintf(cp_image, sizeof(cp_image), "cp -f %s %s", imageName, target_image);
	syslog(INFO, "Copying %s to %s\n", imageName, target_image);
	rc = system(cp_image);
	if (rc == -1) {
		syslog(ERROR, "Failed to install image\n");
		return -1;
	}

	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", cp_image, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", cp_image, rc);
		return -1;
	}
	syslog(INFO, "Done!\n");

	return 0;
}

static int validate_images(int slotNo)
{
	char slotPart[128];
	FILE *fp = NULL;
	int valid = 1;
	int valid_read;
	size_t rc;
	int ret;

	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}
	/* TODO: need to validate the unpacked images, by checksum in manifest.
	 * Put valid flag always as 1 for now */
	if (bootmode == SD_MODE1) {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_EMMC);
		}
		else if (slotNo == 1) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_EMMC);
		}
	}
	else {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_SD);
		}
		else if (slotNo == 1) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_SD);
		}
	}

	strcat(slotPart, SLOT_VALID_FLAG_FILENAME);
	fp = fopen(slotPart, "wb+");
	if (fp == NULL) {
		syslog(ERROR, "Open valid flag file failed\n");
		return -1;
	}

	rc = fwrite(&valid, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "Write valid flag failed\n");
		return -1;
	}

	ret = fseek(fp, 0, SEEK_SET);
	if (ret != 0) {
		syslog(ERROR, "fseek failed\n");
		return -1;
	}
	rc = fread(&valid_read, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "fread failed, return %ld\n", rc);
		return -1;
	}

	syslog(INFO, "valid flag for slot %d is %d\n", slotNo, valid_read);
	fclose(fp);

	return 0;
}

static int unpackPackage(char *fileName)
{
	char rm_command[128];
	char unzipCommand[128];
	int rc;

	/* remove BOOT/bootscr/image if any */
	syslog(INFO, "Deleting %s%s\n", TMP_IMAGE_DIR, "UBOOT.BIN");

	snprintf(rm_command, sizeof(rm_command), "rm -f %s%s", TMP_IMAGE_DIR, "UBOOT.BIN");
	rc = system(rm_command);
	if (rc == -1) {
		syslog(ERROR, "Failed to remove UBOOT\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", rm_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	syslog(INFO, "Done!\n");

	syslog(INFO, "Deleting %s%s\n", TMP_IMAGE_DIR, "boot.scr");
	snprintf(rm_command, sizeof(rm_command), "rm -f %s%s", TMP_IMAGE_DIR, "boot.scr");
	rc = system(rm_command);
	if (rc == -1) {
		syslog(ERROR, "Failed to remove UBOOT\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", rm_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", rm_command, rc);
		return -1;
	}
	syslog(INFO, "Done!\n");

	syslog(INFO, "Deleting %s%s\n", TMP_IMAGE_DIR, "image.ub");
	snprintf(rm_command, sizeof(rm_command), "rm -f %s%s", TMP_IMAGE_DIR, "image.ub");
	rc = system(rm_command);
	if (rc == -1) {
		syslog(ERROR, "Failed to remove image\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", rm_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", rm_command, rc);
		return -1;
	}
	syslog(INFO, "Done!\n");

	syslog(INFO, "Deleting %s%s\n", TMP_IMAGE_DIR, "manifest.xml");
	snprintf(rm_command, sizeof(rm_command), "rm -f %s%s", TMP_IMAGE_DIR, "manifest.xml");
	rc = system(rm_command);
	if (rc == -1) {
		syslog(ERROR, "Failed to remove manifest\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", rm_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", rm_command, rc);
		return -1;
	}
	syslog(INFO, "Done!\n");

	sprintf(unzipCommand, "unzip -o -d %s %s", TMP_IMAGE_DIR, fileName);
	/* Uncompress the software package. */
	rc = system(unzipCommand);
	if (rc == -1) {
		syslog(ERROR, "Failed to unzip package\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", unzipCommand, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", unzipCommand, rc);
		return -1;
	}
	syslog(INFO, "Done!\n");
	return 0;
	
}

int install_software_handler(int slotNo, char *fileName)
{
	char bootName[128];
	char imageName[128];
	int rc;

	sync();
	/* Uncompress the software package. */
	rc = unpackPackage(fileName);
	if (rc != 0) {
		syslog(ERROR, "Unpack package failed\n");
		return -1;
	}
	/* Put BOOT/BOOTSCR/UIMAGE to different partition. */
	sync();
	sprintf(bootName, TMP_IMAGE_DIR);
	strcat(bootName, "BOOT.BIN");
	rc = store_bootbin(slotNo, bootName);
	if (rc != 0) {
		syslog(ERROR, "Store boot.bin failed\n");
		return -1;
	}

	sprintf(imageName, TMP_IMAGE_DIR);
	strcat(imageName, "boot.scr");
	rc = store_image(slotNo, imageName);
	if (rc != 0) {
		syslog(ERROR, "Store %s failed\n", imageName);
		return -1;
	}

	sprintf(imageName, TMP_IMAGE_DIR);
	strcat(imageName, "image.ub");
	rc = store_image(slotNo, imageName);
	if (rc != 0) {
		syslog(ERROR, "Store %s failed\n", imageName);
		return -1;
	}

	sprintf(imageName, TMP_IMAGE_DIR);
	strcat(imageName, "manifest.xml");
	rc = store_image(slotNo, imageName);
	if (rc != 0) {
		syslog(ERROR, "Store %s failed\n", imageName);
		return -1;
	}

	/* Should sync filesystem*/
	sync();
	rc = validate_images(slotNo);
	if (rc != 0) {
		syslog(ERROR, "Validate image failed\n");
		return -2;
	}
	return 0;
}

static int deactivateSlot(int slotNo)
{
	syslog(INFO, "Deactivate software in slot %d\n", slotNo);
	char slotPart[128];
	FILE *fp = NULL;
	int active = 0;
	int active_read;
	size_t rc;
	int ret;

	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}
	if (bootmode == SD_MODE1) {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_EMMC);
		}
		else {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_EMMC);
		}
	}
	else {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_SD);
		}
		else {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_SD);
		}
	}
	strcat(slotPart, SLOT_ACTIVE_FLAG_FILENAME);
	fp = fopen(slotPart, "wb+");
	if (NULL == fp) {
		syslog(ERROR, "fopen %s failed\n", slotPart);
		return -1;
	}

	ret = fseek(fp, 0, SEEK_SET);
	if (ret != 0) {
		syslog(ERROR, "fseek failed\n");
		return -1;
	}
	rc = fwrite(&active, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "fwrite failed, return %ld\n", rc);
		return -1;
	}

	ret = fseek(fp, 0, SEEK_SET);
	if (ret != 0) {
		syslog(ERROR, "fseek failed\n");
		return -1;
	}
	rc = fread(&active_read, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "fread failed, return %ld\n", rc);
		return -1;
	}

	syslog(INFO, "Active flag for slot %d is %d\n", slotNo, active_read);
	fclose(fp);

	return 0;
}

int activate_slot_handler(int slotNo)
{
	char slotPart[128];
	FILE *fp = NULL;
	int active = 1;
	int active_read;
	int slotNo_deactivate;
	size_t rc;
	int ret;

	sync();
	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}
	if (bootmode == SD_MODE1) {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_EMMC);
		}
		else {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_EMMC);
		}
	}
	else {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_SD);
		}
		else {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_SD);
		}
	}
	strcat(slotPart, SLOT_ACTIVE_FLAG_FILENAME);
	fp = fopen(slotPart, "wb+");
	if (NULL == fp) {
		syslog(ERROR, "fopen %s failed\n", slotPart);
		return -1;
	}

	ret = fseek(fp, 0, SEEK_SET);
	if (ret != 0) {
		syslog(ERROR, "fseek failed\n");
		return -1;
	}
	rc = fwrite(&active, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "fwrite failed, return %ld\n", rc);
		return -1;
	}

	ret = fseek(fp, 0, SEEK_SET);
	if (ret != 0) {
		syslog(ERROR, "fseek failed\n");
		return -1;
	}
	rc = fread(&active_read, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "fread failed, return %ld\n", rc);
		return -1;
	}

	syslog(INFO, "Active flag for slot %d is %d\n", slotNo, active_read);
	fclose(fp);

	/* Activate slotNo and deactive the other slot*/
	slotNo_deactivate = MAX_SLOT_NUMBER - slotNo;
	ret = deactivateSlot(slotNo_deactivate);
	if (ret != 0) {
		syslog(ERROR, "Deactivate slot %d failed\n", slotNo_deactivate);
		syslog(INFO, "Trying to restore status of slotNo\n");
		ret = deactivateSlot(slotNo);
		if (ret != 0) {
			syslog(ERROR, "Restore failed\n");
		}
		return -1;
	}
	syslog(INFO, "Activate slot %d succeeded\n", slotNo);
	return 0;
}

static int isSlotValid(int slotNo)
{
	char slotPart[128];
	FILE *fp = NULL;
	int valid_read;
	size_t rc;
	int ret;

	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}
	if (bootmode == SD_MODE1) {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_EMMC);
		}
		else if (slotNo == 1) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_EMMC);
		}
	}
	else {
		if (slotNo == 0) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_SD);
		}
		else if (slotNo == 1) {
			snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_SD);
		}
	}
	strcat(slotPart, SLOT_VALID_FLAG_FILENAME);

	fp = fopen(slotPart, "rb");
	if (fp == NULL) {
		syslog(ERROR, "Open valid flag file failed\n");
		return -1;
	}
	ret = fseek(fp, 0, SEEK_SET);
	if (ret != 0) {
		syslog(ERROR, "fseek failed\n");
		return -1;
	}
	rc = fread(&valid_read, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "fread failed, return %ld\n", rc);
		return -1;
	}

	syslog(ERROR, "Valid flag of slot %d is %d\n", slotNo, valid_read);
	fclose(fp);

	return valid_read;
}

static int checkStatus(int slotNo)
{
        char slotPart[128];

	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}
	if (bootmode == SD_MODE1) {
        	if (slotNo == 0) {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_EMMC);
        	}
        	else {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_EMMC);
        	}
	}
	else {
        	if (slotNo == 0) {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_SD);
        	}
        	else {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_SD);
        	}
	}
        strcat(slotPart, SLOT_VALID_FLAG_FILENAME);

        if (access(slotPart, F_OK) != 0) {
                return SWM_SLOT_EMPTY;
        }
        else if (isSlotValid(slotNo) == 1) {
                return SWM_SLOT_VALID;
        }
        else {
                return SWM_SLOT_INVALID;
        }
}

static int isSlotActive(int slotNo)
{
	char slotPart[128];
	FILE *fp = NULL;
	int active_read;
	size_t rc;
	int ret;

	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}
	if (bootmode == SD_MODE1) {
        	if (slotNo == 0) {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_EMMC);
        	}
        	else {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_EMMC);
        	}
	}
	else {
        	if (slotNo == 0) {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_SD);
        	}
        	else {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_SD);
        	}
	}
	strcat(slotPart, SLOT_ACTIVE_FLAG_FILENAME);
	fp = fopen(slotPart, "rb");
	if (NULL == fp) {
		syslog(ERROR, "fopen %s failed\n", slotPart);
		return -1;
	}

	ret = fseek(fp, 0, SEEK_SET);
	if (ret != 0) {
		syslog(ERROR, "fseek failed\n");
		return -1;
	}

	rc = fread(&active_read, sizeof(int), 1, fp);
	if (rc != 1) {
		syslog(ERROR, "fread failed, return %ld\n", rc);
		return -1;
	}

	syslog(INFO, "Active flag of slot %d is %d\n", slotNo, active_read);
	fclose(fp);

	return active_read;
}

static int findActiveSlot()
{
	int slotNo_active = -1;
	int slotNo;
	int active_count = 0;

	for (slotNo = 0; slotNo <= MAX_SLOT_NUMBER; slotNo++) {
		if (isSlotActive(slotNo)) {
			active_count++;
			slotNo_active = slotNo;
		}
	}
	if (active_count == 0) {
		syslog(ERROR, "No active slot\n");
		return -1;
	}
	if (active_count > 1) {
		syslog(ERROR, "More than 1 active count %d\n", active_count);
		return -2;
	}
	return slotNo_active;
}

static int isSlotCurrent(int slotNo)
{
	char run_command[128];
	char output[8];
	FILE *fp;
	char *p;
	char *endptr = NULL;
	int slotNo_of_current;
	int rc;

	snprintf(run_command, sizeof(run_command), "echo FFD80030 > /sys/firmware/zynqmp/config_reg");

	rc = system(run_command);
	if (rc == -1) {
		syslog(ERROR, "Run %s failed\n", run_command);
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	snprintf(run_command, sizeof(run_command), "cat /sys/firmware/zynqmp/config_reg");

	fp = popen(run_command, "r");
	if (fp == NULL) {
		syslog(ERROR, "popen failed\n");
		return -1;
	}

	p = fgets(output, sizeof(output), fp);
	if (p == NULL) {
		syslog(ERROR, "fgets failed\n");
		fclose(fp);
		return -1;
	}

	rc = fclose(fp);
	if (rc == -1) {
		syslog(ERROR, "fclose failed\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	slotNo_of_current = strtol(output, &endptr, 0);
	syslog(INFO, "Current slot is %d\n", slotNo_of_current);

	return (slotNo_of_current == slotNo) ? 1 : 0;
}

static int setNextRestartSlot(int slotNo)
{
	char run_command[128];
	int rc;

	snprintf(run_command, sizeof(run_command), "echo FFCA0010 > /sys/firmware/zynqmp/config_reg");
	rc = system(run_command);
	if (rc == -1) {
		syslog(ERROR, "Run %s failed\n", run_command);
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	snprintf(run_command, sizeof(run_command), "echo FFCA0010 0xFFFFFFFF %d > /sys/firmware/zynqmp/config_reg", slotNo);
	rc = system(run_command);
	if (rc == -1) {
		syslog(ERROR, "Run %s failed\n", run_command);
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	return 0;

}

static int read_resetmem(size_t *resetmem)
{
	char run_command[128];
	char output[16];
	FILE *fp;
	char *p;
	char *endptr = NULL;
	int rc;

	snprintf(run_command, sizeof(run_command), "echo FFD80054 > /sys/firmware/zynqmp/config_reg");

	rc = system(run_command);
	if (rc == -1) {
		syslog(ERROR, "Run %s failed\n", run_command);
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	snprintf(run_command, sizeof(run_command), "cat /sys/firmware/zynqmp/config_reg");

	fp = popen(run_command, "r");
	if (fp == NULL) {
		syslog(ERROR, "popen failed\n");
		return -1;
	}

	p = fgets(output, sizeof(output), fp);
	if (p == NULL) {
		syslog(ERROR, "fgets failed\n");
		fclose(fp);
		return -1;
	}

	rc = fclose(fp);
	if (rc == -1) {
		syslog(ERROR, "fclose failed\n");
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	*resetmem = strtol(output, &endptr, 0);
	syslog(INFO, "RESET_MEM: 0x%lx\n", *resetmem);

	return 0;
}


static int write_restart_type_in_resetmem(size_t resetmem)
{
	char run_command[128];
	int rc;

	snprintf(run_command, sizeof(run_command), "echo FFD80054 > /sys/firmware/zynqmp/config_reg");
	rc = system(run_command);
	if (rc == -1) {
		syslog(ERROR, "Run %s failed\n", run_command);
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	snprintf(run_command, sizeof(run_command), "echo FFD80054 0x00000F00 0x%x > /sys/firmware/zynqmp/config_reg", resetmem);
	rc = system(run_command);
	if (rc == -1) {
		syslog(ERROR, "Run %s failed\n", run_command);
		return -1;
	}
	if (WIFEXITED(rc)) {
		if (WEXITSTATUS(rc) != 0) {
			syslog(ERROR, "Run %s command failed, exit code: %d\n", run_command, WEXITSTATUS(rc));
			return -1;
		}
	}
	else {
		syslog(ERROR, "Run %s command failed, return code: %d\n", run_command, rc);
		return -1;
	}

	return 0;
}

static int restartBoard()
{
	int rc = 0;
	size_t resetmem;

	rc = read_resetmem(&resetmem);
	if (rc != 0) {
		syslog(ERROR, "Read reset mem failed\n");
		return -1;
	}
	resetmem &= ~PERS_GEN_STORAGE1_RESTART_TYPE_MASK;
	resetmem |= (RESTART_TYPE_ORDERED << PERS_GEN_STORAGE1_RESTART_TYPE_SHIFT);
	rc = write_restart_type_in_resetmem(resetmem);
	if (rc != 0) {
		syslog(ERROR, "Write reset mem failed\n");
		return -1;
	}

	sync();
	rc = reboot(RB_AUTOBOOT);
	if (rc == -1) {
		syslog(ERROR, "Reboot failed\n");
		return -1;
	}

	return 0;
}

int reset_board_handler(void)
{
	int slotNo_active = -1;
	int rc = 0;

	slotNo_active = findActiveSlot();
	if (slotNo_active != 0 && slotNo_active != 1) {
		syslog(ERROR, "Find active slot failed, slotNo active %d\n", slotNo_active);
		return -1;
	}

	rc = setNextRestartSlot(slotNo_active);
	if (rc != 0) {
		syslog(ERROR, "Set next restart slot failed\n");
		return -1;
	}

	rc = restartBoard();
	if (rc != 0) {
		syslog(ERROR, "Restart board failed\n");
		return -1;
	}

	return 0;
}

static int get_image_info(int slotNo, struct image_info_t *p_image_info)
{
	char slotPart[128];
	FILE *fp = NULL;
	char line[256];/*each line in manifest should not exceed 256*/
	int num_of_images = 0;
	char *p;
	char *p_filename;
	char *p_build;
	char *p_token;

	if (slotNo < 0 || slotNo > MAX_SLOT_NUMBER) {
		syslog(ERROR, "Slot number should be 0~%d\n", MAX_SLOT_NUMBER);
		return -1;
	}
	if (bootmode == SD_MODE1) {
        	if (slotNo == 0) {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_EMMC);
        	}
        	else {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_EMMC);
        	}
	}
	else {
        	if (slotNo == 0) {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_0_SD);
        	}
        	else {
                	snprintf(slotPart, sizeof(slotPart), "%s", IMAGE_PARTITION_1_SD);
        	}
	}
	strcat(slotPart, SLOT_MANIFEST_FILENAME);

	fp = fopen(slotPart, "r");
	if (fp == NULL) {
		syslog(ERROR, "Open manifest failed\n");
		return -1;
	}
	memset(line, 0, sizeof(line));
	while ((p = fgets(line, sizeof(line), fp)) != NULL) {
		p_build = strstr(line, BUILD_NAME_PATTERN);
		if (p_build != NULL) {
			p_build += strlen(BUILD_NAME_PATTERN) + 2;
			p_token = strtok(p_build, "\"");
			saft_strcpy(p_image_info->build_name, p_token,sizeof(p_image_info->build_name));
			p_token = strtok(NULL, "\"");
			p_token = strtok(NULL, "\"");
			saft_strcpy(p_image_info->build_rev, p_token,sizeof(p_image_info->build_rev));
			
		}
		p_filename = strstr(line, FILE_NAME_PATTERN);
		if (p_filename != NULL) {
			p_filename += strlen(FILE_NAME_PATTERN) + 2;
			p_token = strtok(p_filename, "\"");
			strcpy(p_image_info->fileInfo[num_of_images].file_name, p_token);
			p_token = strtok(NULL, "\"");
			p_token = strtok(NULL, "\"");
			strcpy(p_image_info->fileInfo[num_of_images].file_rev, p_token);
			p_token = strtok(NULL, "\"");
			p_token = strtok(NULL, "\"");
			strcpy(p_image_info->fileInfo[num_of_images].local_path, p_token);
			p_image_info->fileInfo[num_of_images].integrity = 1;
			num_of_images++;
		}
	}

	if(ferror(fp) != 0) {
		fclose(fp);
		syslog(ERROR, "Read manifest error\n");
		return -1;
	}
	p_image_info->num_of_images = num_of_images;

	fclose(fp);

	return 0;
}

int inventory_handler(int *num_of_slot, struct slot_product_entry_t **product_entry)
{
	struct slot_product_entry_t *pe;
	struct image_info_t image_info;
	int rc;

	pe = calloc(MAX_SLOT_NUM, sizeof(struct slot_product_entry_t));
	if (pe == NULL) {
		syslog(ERROR, "Alloc memory failed\n");
		return -1;
	}

	/* Max slot number, for this demo, it is maximum 2 slots. */
	*num_of_slot = MAX_SLOT_NUM;
	*product_entry = pe;

	for (int i = 0; i < *num_of_slot; i++, pe++)
	{
		pe->slot = i;
		sprintf(pe->slot_name, "slot%d", i);
		pe->status = checkStatus(i);
		pe->is_writable = 1;
		pe->is_active = isSlotActive(i);
		pe->is_current = isSlotCurrent(i);
		/* get image info*/
		rc = get_image_info(i, &image_info);
		if (rc == 0) {
			pe->num_of_images = image_info.num_of_images;
			strcpy(pe->build_name, image_info.build_name);
			strcpy(pe->build_rev, image_info.build_rev);
			memcpy(pe->fileInfo, image_info.fileInfo, sizeof(struct file_info_t) * image_info.num_of_images);
		}
		else {
			pe->num_of_images = 0;
			strcpy(pe->build_name, "ERROR");
			strcpy(pe->build_rev, "ERROR");
			memset(pe->fileInfo, 0, sizeof(struct file_info_t) * 3);
		}
	}
	return 0;
}

void saft_strcpy(char * dest, char *src, size_t dest_size)
{
    if(strlen(src) < dest_size)
    {	
        strcpy(dest, src);
		syslog(INFO,"dest: %s",dest);
    }
    else
    {	
		strcpy(dest,"outsize");
        syslog(ERROR,"build  version or name too long");
    }
}
